#ifndef MINISQL_LOCK_MANAGER_H
#define MINISQL_LOCK_MANAGER_H

/**
 * LockManager handles transactions asking for locks on records.
 *
 * Implemented by student self.
 */
class LockManager {

};

#endif //MINISQL_LOCK_MANAGER_H
